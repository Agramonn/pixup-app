package org.diplomado.pixup.usuario.api.resource;

import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import org.diplomado.pixup.usuario.api.DiscoApi;
import org.diplomado.pixup.usuario.domain.Disco;
import org.diplomado.pixup.usuario.domain.ex.DiscoAlreadyExistsException;
import org.diplomado.pixup.usuario.service.DiscoService;

public class DiscoResource implements DiscoApi {

    @Inject
    private DiscoService discoService;

    @Override
    public Response altaDisco(Disco disco) {
        try {
            Disco discoCreado = discoService.registrarDisco(disco);
            return Response
                    .status(Response.Status.CREATED)
                    .entity(discoCreado)
                    .build();
        }catch (Exception e){
            if(e.getCause() instanceof DiscoAlreadyExistsException){
                return Response
                        .status(Response.Status.CONFLICT)
                        .entity(e.getCause().getMessage())
                        .build();
            }
            return Response
                    .status(Response.Status.PRECONDITION_REQUIRED)
                    .entity(e.getMessage())
                    .build();
        }
    }
}
