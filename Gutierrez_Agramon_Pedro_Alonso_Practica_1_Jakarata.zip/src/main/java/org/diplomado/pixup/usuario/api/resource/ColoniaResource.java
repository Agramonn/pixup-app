package org.diplomado.pixup.usuario.api.resource;

import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import org.diplomado.pixup.usuario.api.ColoniaApi;
import org.diplomado.pixup.usuario.domain.Colonia;
import org.diplomado.pixup.usuario.respository.ColoniaRepository;
import org.diplomado.pixup.usuario.service.ColoniaService;

import java.util.Collection;
import java.util.List;

public class ColoniaResource implements ColoniaApi {

    @Inject
    private ColoniaRepository coloniaRepository;

    @Inject
    private ColoniaService coloniaService;

    @Override
    public Response getColoniaById(Integer id) {
        try {
            Colonia colonia = coloniaService.obtenerColoniaPorId(id);
            return Response
                    .status(Response.Status.OK)
                    .entity(colonia)
                    .build();
        }catch (Exception e){
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity(e.getCause().getMessage())
                    .build();
        }
    }

    @Override
    public Collection<Colonia> getColoniasByCp(String cp) {
        return coloniaRepository.findByCp(cp);
    }
}
