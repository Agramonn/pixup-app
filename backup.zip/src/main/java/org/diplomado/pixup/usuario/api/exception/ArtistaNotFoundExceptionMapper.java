package org.diplomado.pixup.usuario.api.exception;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import org.diplomado.pixup.usuario.domain.ex.ArtistaNotFoundException;

@Provider
public class ArtistaNotFoundExceptionMapper implements ExceptionMapper<ArtistaNotFoundException> {
    @Override
    public Response toResponse(ArtistaNotFoundException e) {
        return Response
                .status(Response.Status.NOT_FOUND)
                .entity(e.getMessage())
                .build();
    }
}
