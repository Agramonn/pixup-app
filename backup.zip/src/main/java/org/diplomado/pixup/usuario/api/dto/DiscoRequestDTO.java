package org.diplomado.pixup.usuario.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DiscoRequestDTO {
    @NotBlank(message = "Titulo es requerido")
    private String titulo;
    private Float precio;
    private Integer existencia;
    private Float descuento;
    private Date fechaLanzamiento;
    private String imagen;
    @NotNull(message = "Artista requerido")
    private Integer artista;
    @NotNull(message = "Disquera requerida")
    private Integer disquera;
    @NotNull(message = "Genero Musical requerido")
    private Integer generoMusical;
}
