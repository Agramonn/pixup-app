package org.diplomado.pixup.usuario.api.exception;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import org.diplomado.pixup.usuario.domain.ex.DiscoAlreadyExistsException;

@Provider
public class DiscoAlreadyExistsExceptionMapper implements ExceptionMapper<DiscoAlreadyExistsException> {
    @Override
    public Response toResponse(DiscoAlreadyExistsException e) {
        return Response
                .status(Response.Status.CONFLICT)
                .entity(e.getMessage())
                .build();
    }
}
