package org.diplomado.pixup.usuario.respository;

import org.diplomado.pixup.usuario.domain.Domicilio;

public interface DomicilioRepository {

    Domicilio save(Domicilio domicilio);
}
